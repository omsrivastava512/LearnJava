# LearnC
All I know about C at one place.
I assume anyone who would like to benefit from this repo has prior basic C syntax knowledge. 
The intention of this repo is to serve as a note section to me and whosoever it interests.

Please note that I have been using the command-line terminal to compile and run my C programs ( GCC version 6.3.0). If you are using another compiler that should not be a problem in most cases.

''>>gcc Main.c

''>>a.exe

or
''>>./a.out
